# Interstellar V6

This is a unstable version of Interstellar rewritten from the ground up. Expect release around the start of the 2024-2025 school year.

## Development

```sh
pnpm i
pnpm disable # Optional: Disables Astro's Telemetry - https://astro.build/telemetry
pnpm dev
```

## Production

```sh
pnpm i
pnpm disable # Optional: Disables Astro's Telemetry - https://astro.build/telemetry
pnpm build
pnpm start
```
